package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Apply;
import com.entity.Contact;
import com.repository.ApplyRepository;

@Service
public class ApplyService {
	 @Autowired
	    private ApplyRepository applyRepository;

	    public void saveApplyNowData(Apply apply) {
	        this.applyRepository.saveApplyNowData(apply);
	    }

	    public List<Apply> getAllApplyData() {
			List<Apply> listofApplicants = this.applyRepository.getApplyData();
			return listofApplicants;
		}

}
