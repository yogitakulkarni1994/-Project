package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Contact;
import com.repository.ContactRepository;

@Service
public class ContactService {
	@Autowired
	ContactRepository contactRepository;

	public void saveContactService(Contact contact) {
		this.contactRepository.saveContactData(contact);
	}

	public List<Contact> getAllContactData() {
		List<Contact> listOfContact = this.contactRepository.getContactData();
		return listOfContact;
	}

}
