package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.SignUp;
import com.repository.SignUpRepository;

@Service
public class SignUpService {
	@Autowired
	SignUpRepository signUpRepository;

	public void saveSignUpService(SignUp signUp) {
		this.signUpRepository.saveSignUpData(signUp);
	}

	public List<SignUp> getAllUserData() {
		List<SignUp> listOfUsers = this.signUpRepository.getAllUsersData();
		return listOfUsers;
	}

}















/*
 * package com.service;
 * 
 * import java.util.List;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Service;
 * 
 * import com.entity.Login; import com.entity.SignUp; import
 * com.repository.SignUpRepository;
 * 
 * @Service public class SignUpService {
 * 
 * 
 * @Autowired SignUpRepository signUpRepository;
 * 
 * 
 * 
 * public void saveSignUpService(SignUp signUp) {
 * this.signUpRepository.saveSignUpData(signUp); }
 * 
 * public List<SignUp> getAllUserData() { List<SignUp> listOfUsers =
 * this.signUpRepository.getAllUsersData(); return listOfUsers; } ////// for
 * login page// public SignUp getUserData(String userName, String password) {
 * SignUp userData = this.signUpRepository.getUserData(userName, password);
 * return userData; } ///////// rohan signup page// public SignUp
 * getUserPresent(String username) { SignUp userData =
 * this.signUpRepository.getUserPresent(username); return userData; }
 * 
 * }
 */