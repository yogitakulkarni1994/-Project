package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.entity.Apply;
import com.entity.Contact;
import com.service.ApplyService;

@Controller
public class ApplyController {
	@Autowired
	ApplyService applyService;
	
	@RequestMapping(path="/applySuccessFul", method = RequestMethod.POST)
	public String saveApplyNowdata(@ModelAttribute Apply apply) {
		this.applyService.saveApplyNowData(apply);
		return "applySuccessFul";
	}

	@RequestMapping(path = "/applicantsData")
	public String applicantsData(Model m) {
		List<Apply> listofApplicants = this.applyService.getAllApplyData();
		m.addAttribute("list", listofApplicants);
		return "applydata";
	}
}
