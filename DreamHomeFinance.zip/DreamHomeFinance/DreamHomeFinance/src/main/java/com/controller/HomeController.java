package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class HomeController {
	@RequestMapping(path="/")
	public String getIndexPage() {
		return "index";
	}
	
	@RequestMapping(path="/about")
	public String getAboutPage() {
		return "about";
	}
	
	@RequestMapping(path="/faq")
	public String getFaqPage() {
		return "faq";
	}
	
	@RequestMapping(path="/contact")
	public String getContactPage() {
		return "contact";
	}
	
	@RequestMapping(path="/login")
	public String getLoginPage() {
		return "login";
	}
	
	@RequestMapping(path="/signup")
	public String getSignUpPage() {
		return "signup";
	}
	
	@RequestMapping(path="/apply")
	public String getApplyPage() {
		return "apply";
	}
	@RequestMapping(path="/admin")
	public String getAdminPage() {
		return "admin";
	}
	
	@RequestMapping(path="/error")
	public String getErrorPage() {
		return "error";
	}
	
	@RequestMapping(path="/terms&conditions")
	public String getTermsPage() {
		return "terms&conditions";
	}
	
	@RequestMapping(path="/privacypolicy")
	public String getPolicyPage() {
		return "privacypolicy";
	}
}
