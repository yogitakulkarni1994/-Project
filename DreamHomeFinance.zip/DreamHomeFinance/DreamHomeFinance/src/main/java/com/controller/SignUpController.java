package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.entity.SignUp;
import com.service.SignUpService;

@Controller
public class SignUpController {
	@Autowired
	SignUpService signUpService;

	@RequestMapping(path = "/signupSuccess", method = RequestMethod.POST)
	public String saveSignUpData(@ModelAttribute SignUp signUp, Model model) {
		this.signUpService.saveSignUpService(signUp);

		List<SignUp> listOfUsers = this.signUpService.getAllUserData();
		model.addAttribute("list", listOfUsers);

		// newly added user info we will display of this page
		model.addAttribute("signUp", signUp);

		return "signupsuccess";
	}

}












/*
 * package com.controller;
 * 
 * import java.util.List;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.ui.Model; import
 * org.springframework.web.bind.annotation.ModelAttribute; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestMethod;
 * 
 * import com.entity.SignUp; import com.service.SignUpService;
 * 
 * @Controller
 * 
 * public class SignUpController {
 * 
 * @Autowired SignUpService signUpService;
 * 
 * @RequestMapping(path="/signupSuccess" , method = RequestMethod.POST) public
 * String saveSignUpData(@ModelAttribute SignUp signUp , Model model) { String
 * username = signUp.getUserName(); SignUp userData =
 * this.signUpService.getUserPresent(username); if (userData != null) { return
 * "signuperror"; } else {
 * 
 * this.signUpService.saveSignUpService(signUp);
 * 
 * List<SignUp> listOfUsers = this.signUpService.getAllUserData();
 * model.addAttribute("list", listOfUsers);
 * 
 * //newly added user info we will display of this page
 * model.addAttribute("signUp" , signUp);
 * 
 * return "signupsuccess"; } } }
 */