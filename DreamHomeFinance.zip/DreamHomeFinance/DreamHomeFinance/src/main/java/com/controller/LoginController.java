/*
 * package com.controller;
 * 
 * import java.util.List;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.ui.Model; import
 * org.springframework.web.bind.annotation.ModelAttribute; import
 * org.springframework.web.bind.annotation.PathVariable; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestMethod; import
 * org.springframework.web.bind.annotation.RequestParam;
 * 
 * import com.entity.Login; import com.entity.SignUp; import
 * com.service.LoginService; import com.service.SignUpService;
 * 
 * @Controller public class LoginController {
 * 
 * 
 * @Autowired LoginService loginService;
 * 
 * @Autowired SignUpService signUpService;
 * 
 * @RequestMapping(path="/",method=RequestMethod.GET) public String
 * getHomePage(Model model) { return "index"; }
 * 
 * @RequestMapping(path="/login",method=RequestMethod.GET) public String
 * getLoginData(Model model) { return "login"; }
 * 
 * @RequestMapping(path="/signup",method=RequestMethod.GET) public String
 * getSignUp(Model model) { return "signup"; }
 * 
 * 
 * 
 * 
 * @RequestMapping(path="/loginsuccess",method=RequestMethod.POST) public String
 * getLoginData(@RequestParam("username") String
 * userName, @RequestParam("password") String password, Model model) { SignUp
 * userData = this.signUpService.getUserData(userName, password); if
 * (userName.equals("bharati") && password.equals("bharati")) { return "index";
 * } else if(userData != null && userName.equals(userData.getUserName()) &&
 * password.equals(userData.getPassword())) { return "index"; }
 * 
 * else { return "loginerror"; } } }
 * 
 */