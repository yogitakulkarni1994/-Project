package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Apply {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// Applicant Information
	private Integer id;
    private String applicantName;
    private String mobileNumber;
    private String email;
    private String occupation;
    private String designation;
    private double salary;

    // Company Information
    private String companyName;
    private String companyEmail;
    private String companyAddress;

    // Address Information
    private String currentAddress;
    private String permanentAddress;

    // Salary and Income Detail
    private double annualSalary;
    private double monthlyIncome;
    private String occupationType;
    private String employerNumber;

    // Loan Detail
    private double loanAmountRequired;
    private int loanTenure;

    // Property Detail
    private String propertyType;
    private String propertyLocation;
    private double propertyValue;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyEmail() {
		return companyEmail;
	}
	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	public String getCurrentAddress() {
		return currentAddress;
	}
	public void setCurrentAddress(String currentAddress) {
		this.currentAddress = currentAddress;
	}
	public String getPermanentAddress() {
		return permanentAddress;
	}
	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}
	public double getAnnualSalary() {
		return annualSalary;
	}
	public void setAnnualSalary(double annualSalary) {
		this.annualSalary = annualSalary;
	}
	public double getMonthlyIncome() {
		return monthlyIncome;
	}
	public void setMonthlyIncome(double monthlyIncome) {
		this.monthlyIncome = monthlyIncome;
	}
	public String getOccupationType() {
		return occupationType;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public String getEmployerNumber() {
		return employerNumber;
	}
	public void setEmployerNumber(String employerNumber) {
		this.employerNumber = employerNumber;
	}
	public double getLoanAmountRequired() {
		return loanAmountRequired;
	}
	public void setLoanAmountRequired(double loanAmountRequired) {
		this.loanAmountRequired = loanAmountRequired;
	}
	public int getLoanTenure() {
		return loanTenure;
	}
	public void setLoanTenure(int loanTenure) {
		this.loanTenure = loanTenure;
	}
	public String getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	public String getPropertyLocation() {
		return propertyLocation;
	}
	public void setPropertyLocation(String propertyLocation) {
		this.propertyLocation = propertyLocation;
	}
	public double getPropertyValue() {
		return propertyValue;
	}
	public void setPropertyValue(double propertyValue) {
		this.propertyValue = propertyValue;
	}
	public Apply(Integer id, String applicantName, String mobileNumber, String email, String occupation,
			String designation, double salary, String companyName, String companyEmail, String companyAddress,
			String currentAddress, String permanentAddress, double annualSalary, double monthlyIncome,
			String occupationType, String employerNumber, double loanAmountRequired, int loanTenure,
			String propertyType, String propertyLocation, double propertyValue) {
		super();
		this.id = id;
		this.applicantName = applicantName;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.occupation = occupation;
		this.designation = designation;
		this.salary = salary;
		this.companyName = companyName;
		this.companyEmail = companyEmail;
		this.companyAddress = companyAddress;
		this.currentAddress = currentAddress;
		this.permanentAddress = permanentAddress;
		this.annualSalary = annualSalary;
		this.monthlyIncome = monthlyIncome;
		this.occupationType = occupationType;
		this.employerNumber = employerNumber;
		this.loanAmountRequired = loanAmountRequired;
		this.loanTenure = loanTenure;
		this.propertyType = propertyType;
		this.propertyLocation = propertyLocation;
		this.propertyValue = propertyValue;
	}
	public Apply() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Apply [id=" + id + ", applicantName=" + applicantName + ", mobileNumber=" + mobileNumber + ", email="
				+ email + ", occupation=" + occupation + ", designation=" + designation + ", salary=" + salary
				+ ", companyName=" + companyName + ", companyEmail=" + companyEmail + ", companyAddress="
				+ companyAddress + ", currentAddress=" + currentAddress + ", permanentAddress=" + permanentAddress
				+ ", annualSalary=" + annualSalary + ", monthlyIncome=" + monthlyIncome + ", occupationType="
				+ occupationType + ", employerNumber=" + employerNumber + ", loanAmountRequired=" + loanAmountRequired
				+ ", loanTenure=" + loanTenure + ", propertyType=" + propertyType + ", propertyLocation="
				+ propertyLocation + ", propertyValue=" + propertyValue + "]";
	}
    

}
