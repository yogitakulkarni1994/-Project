package com.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.SignUp;

@Repository
public class SignUpRepository {
	@Autowired
	HibernateTemplate hibernateTemplate;

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@Transactional
	public void saveSignUpData(SignUp signUp) {
		this.hibernateTemplate.save(signUp);

	}

	public List<SignUp> getAllUsersData() {
		List<SignUp> listofSignUp = this.hibernateTemplate.loadAll(SignUp.class);
		return listofSignUp;
	}
}











/*
 * package com.repository;
 * 
 * import java.util.List;
 * 
 * import org.hibernate.Session; import org.hibernate.query.Query; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.orm.hibernate5.HibernateTemplate; import
 * org.springframework.stereotype.Repository; import
 * org.springframework.transaction.annotation.Transactional;
 * 
 * import com.entity.SignUp;
 * 
 * @Repository public class SignUpRepository {
 * 
 * @Autowired HibernateTemplate hibernateTemplate;
 * 
 * public HibernateTemplate getHibernateTemplate() { return hibernateTemplate; }
 * 
 * public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
 * this.hibernateTemplate = hibernateTemplate; }
 * 
 * 
 * @Transactional public void saveSignUpData(SignUp signUp ) {
 * this.hibernateTemplate.save(signUp);
 * 
 * }
 * 
 * 
 * public List<SignUp> getAllUsersData() { List<SignUp> listofSignUp =
 * this.hibernateTemplate.loadAll(SignUp.class); return listofSignUp; } //////
 * for login page//
 * 
 * @Transactional public SignUp getUserData(String username, String password) {
 * // Get the current session Session session = Session session =
 * this.hibernateTemplate.getSessionFactory().getCurrentSession();
 * 
 * // Use HQL to query the database for the user by username String queryString
 * String queryString =
 * "FROM SignUp WHERE userName = :userName AND password = :password"; //
 * Query<Login> query = session.createQuery(queryString, Login.class);
 * Query<SignUp> query = session.createQuery(queryString, SignUp.class);
 * query.setParameter("userName", username); query.setParameter("password",
 * password); List<SignUp> userLoginData = query.getResultList();
 * if(!userLoginData.isEmpty()) { return userLoginData.get(0); } return null; }
 * ///////// rohan signup page//
 * 
 * @Transactional public SignUp getUserPresent(String username) { // Get the
 * current session Session session = Session session =
 * this.hibernateTemplate.getSessionFactory().getCurrentSession();
 * 
 * // Use HQL to query the database for the user by username String queryString
 * String queryString = "FROM SignUp WHERE userName = :userName"; //
 * Query<Login> query = session.createQuery(queryString, Login.class);
 * Query<SignUp> query = session.createQuery(queryString, SignUp.class);
 * query.setParameter("userName", username); List<SignUp> userLoginData =
 * query.getResultList(); if(!userLoginData.isEmpty()) { return
 * userLoginData.get(0); } return null; } }
 * 
 */