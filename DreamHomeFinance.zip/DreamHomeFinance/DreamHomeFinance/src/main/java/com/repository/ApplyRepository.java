package com.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.Apply;
import com.entity.Contact;

@Repository
public class ApplyRepository {
	  @Autowired
	    private HibernateTemplate hibernateTemplate;
	    
	    public HibernateTemplate getHibernateTemplate() {
			return hibernateTemplate;
		}

		public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
			this.hibernateTemplate = hibernateTemplate;
		}

		@Transactional
	    public void saveApplyNowData(Apply apply) {
	        this.hibernateTemplate.save(apply);
	    }
		
		public List<Apply> getApplyData() {
			List<Apply> listofApplicants = this.hibernateTemplate.loadAll(Apply.class);
			return listofApplicants;
		}
}
